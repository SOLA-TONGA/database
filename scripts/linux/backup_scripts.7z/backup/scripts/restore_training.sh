#!/bin/bash
#                   SOLA Restore Training Script (Linux)
#
# Author: Andrew McDowell 
# Date: 05 Mar 2014
# 
# This script uses the PostgreSQL pg_restore utility to restore 
# a production backup from the SOLA database into a Test or
# Training environment. This ensures any secondary SOLA environment
# (a.k.a. Training) can be synchronized with the production 
# environment at regular intervals. 
# 
# This script also ensures any new documents added to the production
# database are copied into the training environment. As the documents
# table can grow to very large sizes, this restore is based around
# restoring a partial backup of documents as created by the 
# backup_sola_docs.sh script. 
# 
# This script is NOT intended to make Training a hot backup of 
# production, but simply to keep the data between the two 
# environments relatively in sync. It should be run once a day
# at most, but can be run on an ad-hoc basis if required. 
#
# This script requires access to the Training database from the
# production server. This may require re-configuration of the 
# PostgreSQL pg_hba.conf and postgresql.conf files on the Training
# database to enable remote access. 
#
# The script will prompt the user (interactive mode) if the -p
# option is not provided as a parameter. The command
# options recognized are 
#   -p: Run the script in interactive mode
#   -s: The name of the server hosting the Training database
#   -d: Name of the Training database to restore the backup to
#  
# Examples:
# 1) To restore the training data to the landsgis server
#    > ./restore_training.sh -s landsgis -d sola_test
# 2) To run the script in interactive mode
#    > ./restore_training.sh -p
# 
# DATABASE PASSWORD
# PGPASSWORD and PGPASSFILE are no longer accepted by
# postgresql so the only way to authenticate with the 
# database is to use a .pgpass file. The .pgpass file
# must be located in the Home directory of the user running
# the script. The script will notify the user and stop if 
# the .pgpass file does not exist.
#
# The format for each line in the .pgpass file is  
#        host:port:database:username:password
# * can be used as a wildcard.  e.g.
#       locahost:5432:*:postgres:<DB Password>
# The .pgpass file must have rw permissions for the user ONLY!
# e.g. chmod 0600 .pgpass 

# Configure variables to use for script:

# The current directory where this command has been executed from
# current_dir=$(pwd) 
current_dir="/opt/sola/backup/scripts"
# Root directory for the database backups 
backup_root_dir="$current_dir/../"
# Default install location for pg_restore on linux/Debian. This location
# may need to be modified if a different version of postgresql
# is being used and/or it is installed in a custom location.
pg_restore="/usr/lib/postgresql/9.3/bin/pg_restore"
psql="/usr/lib/postgresql/9.3/bin/psql"

# Default Training DB connection values
host=landsgis
port=5432
dbname=sola_test
username=postgres

prompt=N
frequency=05-Train

# Capture options from the command line
OPTIND=1 # Reset for getopts in case it was used previously.
while getopts "hs:pd:" opt; do
  case $opt in
    s) host=$OPTARG
       ;;
    h) echo "Valid options: -s <Training Server> -d <Training database name>" 
       exit 0
       ;;
    p) prompt=Y
       ;;
    d) dbname=$OPTARG
       ;;
    \?) echo "Invalid option: -$OPTARG" >&2
        exit 1
        ;;
    :) echo "Option -$OPTARG requires an argument." >&2
       exit 1
       ;;
  esac
done
shift $((OPTIND-1)) # Shift off the options and optional --.

# Check if password has been set. If not, assume the script is
# being run interactively and prompt for details
if [ $prompt == "Y" ]; then
   read -p "Training database host [$host] : " input
   host=${input:-$host}
   read -p "Training database name [$dbname] : " input
   dbname=${input:-$dbname}
fi

# Obtain a formatted date to use in the file names
datestr=$(date +"%Y%m%d_%H%M")

RESTORE_LOG="$backup_root_dir$frequency/sola-R-$datestr.log"
BACKUP_FILE_TRAIN="$backup_root_dir$frequency/sola-T-main.backup"
BACKUP_FILE_HIST="$backup_root_dir$frequency/sola-T-hist.backup"
BACKUP_FILE_DOCS="$backup_root_dir$frequency/sola-docs-T-train.backup"
PGPASS="$HOME/.pgpass"
 
 # Start the backup
echo
echo 
echo "Starting Backup at $(date)"
echo "Starting Backup at $(date)" > $RESTORE_LOG 2>&1
echo "Backup File = $BACKUP_FILE_TRAIN"
echo "Backup File = $BACKUP_FILE_TRAIN" >> $RESTORE_LOG 2>&1

# Determine if the .pgpass file exists.
if [ ! -f  $PGPASS]; then
   echo "$PGPASS does not exist! - Exiting"
   echo "$PGPASS does not exist! - Exiting" >> $RESTORE_LOG 2>&1
   exit 1
fi

# Restore the main backup to the Training database
echo "Restoring main backup..."
echo "Restoring main backup..." >> $RESTORE_LOG 2>&1
$pg_restore -h $host -p $port -U $username -d $dbname -c \
		-j 3 $BACKUP_FILE_TRAIN >> $RESTORE_LOG 2>&1

# Restore the history backup to the Training database
echo "Restoring history backup..."
echo "Restoring history backup..." >> $RESTORE_LOG 2>&1
$pg_restore -h $host -p $port -U $username -d $dbname -c \
		-j 3 $BACKUP_FILE_HIST >> $RESTORE_LOG 2>&1
		
# Restore the documents backup to the Training database
echo "Restoring documents backup..."
echo "Restoring documents backup..." >> $RESTORE_LOG 2>&1
$pg_restore -h $host -p $port -U $username -d $dbname -c \
		-j 3 $BACKUP_FILE_DOCS >> $RESTORE_LOG 2>&1
		
# Copy documents from the document_backup table using a psql command
echo "Copy documents from document_backup..."
echo "Copy documents from document_backup..." >> $RESTORE_LOG 2>&1
$psql -h $host -p $port -U $username -d $dbname \
	 -c "INSERT INTO document.document (id, nr, extension, body, description, rowidentifier, 
                                        rowversion, change_action, change_user, change_time) 
         SELECT id, nr, extension, body, description, rowidentifier, rowversion, change_action, 
                change_user, change_time 
         FROM document.document_backup d  
         WHERE NOT EXISTS (SELECT id FROM document.document WHERE id = d.id);" >> $RESTORE_LOG 2>&1

# Report the finish time
echo "Finished at $(date)"
echo "Finished at $(date)" >> $RESTORE_LOG 2>&1


